class SWItem:
    def __init__(self):
        equipavel = False
        partes_corpo = []
        acoes = []
        efeitos = []
        tipo = None